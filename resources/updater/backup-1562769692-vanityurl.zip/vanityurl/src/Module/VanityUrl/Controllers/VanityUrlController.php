<?php

namespace Module\VanityUrl\Controllers;

/*
 * Controller: VanityUrl
 * @Atlantis CMS
 * v 1.0
 */

use App\Http\Controllers\Controller;
use Module\VanityUrl\Models\Repositories\VanityUrlRepository;
use Illuminate\Support\Facades\URL;
class VanityUrlController extends Controller {

  public function __construct() {
    
  }

  public function redirect( $path) {

   //$requestUrl = URL::full();
      $query = request()->getQueryString();
      if ($query && strlen($query)) {
          $path = $path .  "?" . request()->getQueryString();

      }

    $result = VanityUrlRepository::findSourceURL($path);


    if ($result != NULL) {
      return redirect($result->dest_url)->send();
    }
  }

}
