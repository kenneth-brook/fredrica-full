    
    <div class="masonry-wrapper blog row">
        <div class="grid-sizer medium-6 columns">&nbsp;</div>
        @foreach ($oBlogs as $blog)
            <div class="grid-item blog-item medium-6 columns">
                <div class="shadow-box columns">
                    @if (isset($featuredImages[$blog->id]))
                        <div class="blog-img">
                            <a href="javascript:void(0);">
                                <img src="{!! $featuredImages[$blog->id]['thumbnail'] !!}">
                            </a>
                        </div>
                    @endif
                    <h3>{{ $blog->title }}</h3>
                    @if($blog->use_blurb == 0)
                            {{ \Illuminate\Support\Str::words( strip_tags($blog->body), $blog->body_words, '...') }}
                    @else
                        {{ $blog->blurb }}
                    @endif

                    <a class="button large" href="{{ $single_url . '' . $blog->url }}">READ MORE</a>
                    <div class="blog-bottom-row small-12">
                        <div class="date small-5 columns">{!! \Carbon\Carbon::createFromFormat('Y-m-d h:i:s',$blog->posted_date)->format('F d, Y') !!}</div>
                        <div class="small-6 columns">
                            <?php
                                $addThis = new \Module\Addthis\Controllers\AddthisController();
                            ?>
                            {!! $addThis->set($blog->title, url($single_url . $blog->url)) !!}
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    </div>

{{$oBlogs->links('blog::pagination')}}