@if(count($prev))
<div class="jump-to-prev">
    <div class="shadow-box">
        <a class="details" href="/rv-news/{{ $prev->url }}">{{ $prev->title }}</a>
        <a href="/rv-news/{{ $prev->url }}">
        <span class="button">
            <span class="date">{{ \Carbon\Carbon::createFromFormat('Y-m-d h:i:s', $prev->posted_date)->format('m-d-y') }}</span>
        </span>
        </a>
    </div>
    <a class="reveal-block" href="/rv-news/{{ $prev->url }}"><span></span></a>
</div>
@endif

@if(count($next))
<div class="jump-to-next">
    <div class="shadow-box">
        <a class="details" href="/rv-news/{{ $next->url }}">{{ $next->title }}</a>
        <a class="" href="/rv-news/{{ $next->url }}">
        <span class="button">
            <span class="date">{{ \Carbon\Carbon::createFromFormat('Y-m-d h:i:s', $next->posted_date)->format('m-d-y') }}</span>
        </span>
        </a>
    </div>
    <a class="reveal-block" href="/rv-news/{{ $next->url }}"><span></span></a>
</div>
@endif