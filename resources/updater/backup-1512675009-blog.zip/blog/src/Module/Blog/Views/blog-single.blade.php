<h1>{{ $data->title }}</h1>

<h2>{{ \Carbon\Carbon::createFromFormat('Y-m-d h:i:s', $data->posted_date)->format('F d, Y') }}</h2>
<?php
$addThis = new \Module\Addthis\Controllers\AddthisController();
?>
{!! $addThis->set($data->title, url(URL::to('/').'/'. $data->url)) !!}

{{ $data->body }}

@if(!empty($data->gallery_id))
    <div class="masonry-wrapper masonry-gallery row">
        <div class="grid-sizer">&nbsp;</div>
        @foreach (\MediaTools::getImagesByGallery($data->gallery_id) as $image)
            <div class="grid-item">
                <img src="{!! $image->thumbnail !!}">
            </div>
        @endforeach
    </div>
@endif


@if(!empty($story))
    {{ $story }}
@endif