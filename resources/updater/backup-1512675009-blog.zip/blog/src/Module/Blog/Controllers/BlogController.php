<?php

namespace Module\Blog\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Middleware\RedirectIfAuthenticated;
use Atlantis\Helpers\AtlantisRedirect;
use Atlantis\Models\Repositories\PageRepository;
use Module\Blog\Models\Repositories\BlogRepository;
use Illuminate\Support\Facades\DB;
use Module\Blog\Models\Repositories\BlogConfigRepository;

class BlogController extends Controller
{

    use \Module\Blog\Traits\BlogTrait;

    public static $title;
    public static $description;

    /**
     * <div data-pattern-func="module:blog@single"></div>
     */
    public function single()
    {

        $base_route = \Route::input('page');

        //this is dumb and needs to be replaced .. maybe change the config to have the anchor url be not connected to an actual page
        $page = str_replace("/:any", "",PageRepository::getPage(BlogConfigRepository::getConfigKey('single_url'))->url);

        $entry = DB::table('blog')->where(DB::raw('CONCAT("' . $page . '/", url)'), $base_route)->first();
        
        if ($entry->status == 'draft' && is_null(auth()->user())) {
            
            return app('AtlantisRedirect')->set(redirect()->to('404'));
            
        }
        if (count($entry))
        {

            $data = array();

            $data['data'] = $entry;

            $data['comment_engine'] = BlogConfigRepository::getConfigKey('comment_engine');
            if ($entry->seo_title == ''){
                self::$title = $entry->title;
            }
            else{
                self::$title = $entry->seo_title;   
            }
            self::$description = $entry->meta_description;

            $images = \MediaTools::getImagesByGallery($entry->gallery_id);
            $data['images'] = $images;

            $ogData = [
                'type' => 'article',
                'title' => $entry->title,
                'description' => $entry->description,
                'url' => url(BlogConfigRepository::getConfigKey('single_url') . '/' . $entry->url),
                'author' => $entry->nickname
            ];

            if (isset($images[0]))
            {
                $ogData['image'] = url($images[0]->original_filename);
            }

            \Atlantis\Helpers\Assets::registerContentWithKey('opengraph', $ogData);

            return view('blog::blog-single', $data);

        } else
        {

            return app('AtlantisRedirect')->set(redirect()->to('404'));
        }
    }

    /**
     * <div data-pattern-func="module:blog@all"></div>
     */
    public function all()
    {

        $oBlogs = BlogRepository::getAllPublished();

        $featuredImages = \MediaTools::getFeaturedImages($oBlogs);

        $aParams = array();
        $aParams['oBlogs'] = $oBlogs;
        $aParams['featuredImages'] = $featuredImages;

        $single_url = PageRepository::getPage(BlogConfigRepository::getConfigKey('single_url'));

        if ($single_url->url == "/")
        {
            $aParams['single_url'] = '/';
        } else
        {
            $aParams['single_url'] = '/' . $single_url->url;
        }

        $aParams['single_url'] = str_replace(":any", "",$aParams['single_url']);

        $aParams['datetime_format'] = BlogConfigRepository::getConfigKey('datetime_format');

        //$aParams['paginator'] = '';

        return view('blog::blog-list', $aParams);
    }

    public function quicklinks()
    {
        /*$url = explode("rv-news/", $this->request->url());*/
        $base_route = \Route::input('page');

        //this is dumb and needs to be replaced .. maybe change the config to have the anchor url be not connected to an actual page
        $page = str_replace("/:any", "",PageRepository::getPage(BlogConfigRepository::getConfigKey('single_url'))->url);

        $entry = DB::table('blog')->where(DB::raw('CONCAT("' . $page . '/", url)'), $base_route)->first();

        $url = url(BlogConfigRepository::getConfigKey('anchor_url') . '/' . $entry->url);

        $model = $entry;

        $data = [];

        if(count($model))
        {
            $data['next'] = \DB::table('blog')->select('*')->where('posted_date', '>', $model->posted_date)->where('status', 'published')->orderBy('posted_date')->limit(1)->first();
            $data['prev'] = \DB::table('blog')->select('*')->where('posted_date', '<', $model->posted_date)->where('status', 'published')->orderBy('posted_date', 'DESC')->limit(1)->first();
        }

        return view('blog::quick-links', $data);

    }

    public function getRecentShort($params)
    {
        $amount = $params[0];
        return BlogRepository::getRecentShort($amount);
        
    }
    

}
