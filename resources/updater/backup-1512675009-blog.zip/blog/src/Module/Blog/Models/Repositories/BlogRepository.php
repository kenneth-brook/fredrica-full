<?php

namespace Module\Blog\Models\Repositories;

use Atlantis\Helpers\Cache\AtlantisCache;
use Module\Blog\Models\Blog;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Module\Blog\Models\Categories;
use Module\Blog\Models\CategoriesLu;
use Atlantis\Models\Repositories\PageRepository;

/**
 * Class BlogRepository
 * @package Module\Blog\Models\Repositories
 */
class BlogRepository
{

    public static $_POSTED_DATE_FORMAT_VIEW = 'm/d/Y';

    /**
     * @param $data
     * @param null $id
     * @return mixed
     */
    public function validationCreate($data, $id = NULL)
    {

        $rules_create = [
            'title' => 'required',
            'url' => 'required|unique:blog,url,' . $id . '|valid_url',
            'nickname' => 'required',
            'posted_date' => 'date_format:' . self::$_POSTED_DATE_FORMAT_VIEW,
        ];

        $messages = [
            'required' => trans('blog::validation.required'),
            'unique' => trans('blog::validation.unique'),
            'valid_url' => trans('blog::validation.valid_url'),
            'date_format' => trans('blog::validation.date_format')
        ];

        return Validator::make($data, $rules_create, $messages);
    }

    /**
     * @param $data
     * @return mixed
     */
    public function validationCreateCategory($data)
    {
        $rules_create = [
            'category_name' => 'required|unique:blog_categories,category_name'
        ];

        $messages = [
            'required' => trans('blog::validation.required'),
            'unique' => trans('blog::validation.unique'),
        ];

        return Validator::make($data, $rules_create, $messages);
    }

    /**
     * @param $data
     * @param $id
     * @return mixed
     */
    public function validationEditCategory($data, $id)
    {
        $rules_create = [
            'category_name' => 'required|unique:blog_categories,category_name,' . $id
        ];

        $messages = [
            'required' => trans('blog::validation.required'),
            'unique' => trans('blog::validation.unique'),
        ];

        return Validator::make($data, $rules_create, $messages);
    }

    /**
     * @param $data
     * @return mixed
     */
    public function validationEdit($data)
    {

        return Validator::make($data, $this->rules_create);
    }

    /**
     * @param $data
     * @return mixed
     */
    public function add($data)
    {

        if (empty($data['posted_date']))
        {
            $data['posted_date'] = NULL;
        } else
        {
            $data['posted_date'] = Carbon::createFromFormat(self::$_POSTED_DATE_FORMAT_VIEW . ' H:i:s', $data['posted_date'] . ' 00:00:01')->toDateTimeString();
        }

        $model = Blog::create($data);

        \Atlantis\Models\Repositories\TagRepository::addTagsWithDelimiter(',', $data['tags'], $model->id, 'blog');

        return $model->id;
    }

    /**
     * @param $id
     * @param $data
     * @return bool
     */
    public function edit($id, $data)
    {

        if (empty($data['posted_date']))
        {
            $data['posted_date'] = NULL;
        } else
        {
            $data['posted_date'] = Carbon::createFromFormat(self::$_POSTED_DATE_FORMAT_VIEW . ' H:i:s', $data['posted_date'] . ' 00:00:01')->toDateTimeString();
        }

        if (!isset($data['use_blurb']))
        {
            $data['use_blurb'] = 0;
        }

        $model = Blog::findOrNew($id);

        if ($model != NULL)
        {
            $model->update($data);

            \Atlantis\Models\Repositories\TagRepository::updateTagsWithDelimiter(',', $data['tags'], $model->id, 'blog');

            return TRUE;
        } else
        {
            return FALSE;
        }
    }

    /**
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public static function getAll()
    {

        //return Blog::all();
        return Blog::paginate(BlogConfigRepository::getConfigKey('per_page'));
    }

    /**
     * @return mixed
     */
    public static function getAllPublished()
    {
        return Blog::where('status', '=', 'published')->paginate(BlogConfigRepository::getConfigKey('per_page'));
    }

    /**
     * @param $id
     * @return mixed
     */
    public static function get($id)
    {

        return Blog::find($id);
    }

    /**
     * @param $id
     * @return bool
     */
    public static function deleteEntry($id)
    {

        $model = Blog::findOrNew($id);

        if ($model != NULL)
        {
            $model->delete();

            \Atlantis\Models\Repositories\TagRepository::deleteTag('blog', $id);

            return TRUE;
        } else
        {
            return FALSE;
        }
    }

    /**
     * @return mixed
     */
    public static function getRecentShort($amount)
    {

        $data['recent'] = Blog::where('status', 'published')->orderBy('posted_date', 'DESC')->take($amount)->get();

        $data['anchor_url'] = str_replace("/:any", "",PageRepository::getPage(BlogConfigRepository::getConfigKey('single_url'))->url);
        

        return \View::make('blog::recent-short', $data);

    }

    /**
     * @return mixed
     */
    public function getArchivesForMonth()
    {
        $month = request()->get('month');

        $data = [];

        $parsedMonth = strtotime("01-" . $month);

        $data['list'] = null;

        $data['month'] = $month;

        $data['anchor_url'] = AtlantisCache::rememberQuery('blogAnchorURL', [$month], function ()
        {
            return BlogConfigRepository::getConfigKey('anchor_url') . "/";
        });

        if ($parsedMonth)
        {
            $data['list'] = AtlantisCache::rememberQuery('getMonthArchive', [$month], function () use ($month)
            {
                return $list = \DB::table('blog')
                    ->select('*')
                    ->where(\DB::raw('DATE_FORMAT(posted_date,\'%m-%Y\')'), $month)
                    ->where('status', 'published')
                    ->orderBy('posted_date', 'DESC')
                    ->get();
            });

        }

        return \View::make('blog::archives-list', $data);

    }

    /**
     * @return mixed
     */
    public function getMakeArchivesList()
    {
        //SELECT blog.posted_date,DATE_FORMAT(posted_date, '%m-%Y') AS created FROM blog GROUP BY created ORDER BY posted_date DESC

        $data['list'] = AtlantisCache::rememberQuery('getArchivesList', ['getArchivesList'], function ()
        {
            return $list = \DB::table('blog')
                ->select(\DB::raw('blog.posted_date, DATE_FORMAT(posted_date, \'%m-%Y\') AS created'))
                ->where('status', 'published')
                ->groupBy('created')
                ->orderBy('posted_date', 'DESC')
                ->get();
        });

        return \View::make('blog::archives-dates-list', $data);

    }

    /**
     * <div data-pattern-func="module:blog@allOrdered"></div>
     */
    public function allOrdered()
    {

        $oBlogs = AtlantisCache::rememberQuery('getAllBlogsOrdered', 'getAllBlogsOrdered', function ()
        {
            return Blog::where('status', 'published')
                ->orderBy('posted_date', 'DESC')
                ->get();
        });

        $featuredImages = \MediaTools::getFeaturedImages($oBlogs);

        $aParams = array();

        $aParams['oBlogs'] = $oBlogs;
        $aParams['featuredImages'] = $featuredImages;
        $aParams['anchor_url'] = BlogConfigRepository::getConfigKey('anchor_url');

        return view('blog::blog-list', $aParams);
    }


    /**
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public static function getCategories()
    {
        return Categories::all();
    }

    /**
     * @param $data
     */
    public static function addCategory($data)
    {
        Categories::create($data);
    }

    /**
     * @param $id
     * @return mixed
     */
    public static function getCategory($id)
    {
        return Categories::find($id);
    }

    /**
     * @param $id
     * @param $data
     */
    public static function updateCategory($id, $data)
    {
        Categories::find($id)->update($data);
    }

    /**
     * @param $id
     * @return mixed
     */
    public static function deleteCategory($id)
    {
        return Categories::find($id)->delete();

    }

    /**
     * @param $category_id
     */
    public static function deleteCategoryLuCategoryId($category_id)
    {
        CategoriesLu::where('category_id', $category_id)->delete();
    }

    /**
     * @param $blog_id
     */
    public static function deleteCategoryLuBlogId($blog_id)
    {
        CategoriesLu::where('blog_id', $blog_id)->delete();
    }

    /**
     * @param $data
     */
    public static function addCategoryLu($data)
    {
        CategoriesLu::create($data);
    }


    /**
     * @param $cat_id
     * @param null $limit
     * @return mixed
     */
    public static function getBlogsByCategoryId($cat_id, $limit = null)
    {
        return AtlantisCache::rememberQuery('getBlogsByCategoryId', [$cat_id], function() use($cat_id, $limit)
        {

            $result = Blog::whereHas('categories', function($q) use ($cat_id)
            {
                $q->where('category_id', $cat_id);

            })->where('status', 'published');

            if(!is_null($limit))
            {
                $result->take($limit);
            }

            $result->orderBy('posted_date', 'DESC');

            return $result->get();

        });
    }

}
