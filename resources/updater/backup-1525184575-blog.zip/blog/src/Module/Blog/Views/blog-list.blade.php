@foreach ($oBlogs as $blog)
<div class="entry">
    <h3>{{ $blog->title }}</h3>
    <p class="time-class">{!! \Carbon\Carbon::createFromFormat('Y-m-d h:i:s',$blog->posted_date)->format('F d, Y') !!}</p>
    <p>                        
        @if($blog->use_blurb == 0)
        {{ \Illuminate\Support\Str::words( strip_tags($blog->body), $blog->body_words, '...') }}
        @else
        {{ $blog->blurb }}
        @endif
    </p>
    <a href="{{ $single_url . '' . $blog->url }}">READ STORY</a>
    <br>
    <hr>
</div>
@endforeach
{{-- use just $oBlogs for old A3 installs --}}
{{$oBlogs->links('blog::pagination')}}