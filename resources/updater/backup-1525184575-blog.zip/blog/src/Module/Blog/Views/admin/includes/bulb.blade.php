<div class="helper">
    <button type="button" class="icon icon-Bulb" data-panel-toggle="tips-panel"></button>
    <div class="right-panel side-panel" id="tips-panel" data-atlantis-panel>
        <ul class="accordion" data-accordion>
            <li class="accordion-item is-active" data-accordion-item>
                <a href="#" class="accordion-title">Showing single/individual blog items</a>
                <div class="accordion-content" data-tab-content>
                    To show individual blog items, you can use the element <b> &lt;div data-pattern-func="module:blog@single"&gt;&lt;/div&gt;</b> in any page.

                </div>
            </li>
            <li class="accordion-item" data-accordion-item>
                <a href="#" class="accordion-title">Showing All Blog Items</a>
                <div class="accordion-content" data-tab-content>
                    To show all blog items, you can use the element <b>&lt;div data-pattern-func="module:blog@all"&gt;&lt;/div&gt;</b> in any page. 
                </div>
            </li>
            <li class="accordion-item" data-accordion-item>
                <a href="#" class="accordion-title">Showing Recent</a>
                <div class="accordion-content" data-tab-content>
                    To show 3 recent post (short) <b>&lt;div data-pattern-func="module:blog@recentshort-3"&gt;&lt;/div&gt;</b> in any page. 
                </div>
            </li>
            <li class="accordion-item" data-accordion-item>
                <a href="#" class="accordion-title">Showing brev next buttons</a>
                <div class="accordion-content" data-tab-content>
                    Usuly right after blog single pattern func  <b>&lt;div data-pattern-func="module:blog@quicklinks"&gt;&lt;/div&gt;</b> in any page. 
                </div>
            </li>
        </ul>
    </div>
</div>