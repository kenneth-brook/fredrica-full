<div class="reveal" id="cloneForm{{$obj->id}}" data-reveal>

    <form method='post' action='/admin/modules/forms/clone-form/{{$obj->id}}' >
            {!!  csrf_field() !!}
        <h1>Clone Form</h1>
        <hr>
        <input type='hidden' name='form_id' value='{{$obj->id}}'> 
        <label for="clone-name">Clone Name
            <input type='text' name='clone-name' value='{{$obj->name}}-Clone'>
        </label>    

        <hr>
        <input type='submit' name='submit-clone' value='Clone' class='button danger'>
    </form>

</div>