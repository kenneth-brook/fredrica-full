{!! $form->submit_with_ajax || $form->hide_form_upon_success || $form->use_front_end_validation ?  \Atlantis\Helpers\Assets::registerScript('modules/atlantis/forms/src/Module/Forms/Assets/ajax_submit.js', 6000 ) : "" !!}
{!! $form->submit_with_ajax || $form->hide_form_upon_success ?   \Atlantis\Helpers\Assets::registerScript('https://code.jquery.com/jquery-1.12.4.min.js', 9)  : "" !!}

<div class="msg-container" id="msg-form-{{ $escaped_name }}">

@if (Session::has('success'))
  {{-- show success message --}}
  <div class="success">
    <span data-form-name="{{$form->name}}" class="success-msg">{{ Session::get('success') }}</span>
  </div>
@endif
@if ($errors->all())
    
    <div class="fail">
    @if ($errors->has('flood_control'))
        {{$errors->first('flood_control')}}
    @else
        {{ !empty($form->error_message) ? $form->error_message : 'Some of the form fields were not completed, please review your form and submit again.'}}
    @endif
    </div>
@endif


</div>
@if (!(Session::has("success") && $form->hide_form_upon_success))
{!! Form::open(array_merge(['url' => $url,
'data-hide-after-submit' => $form->hide_form_upon_success ? 1 : 0,
'data-use-ajax' => $form->submit_with_ajax ? 1 : 0,
'data-is-custom-form' => 1,
'data-use_front_end_validation' => $form->use_front_end_validation ? 1 : 0,
'data-error_wrapper_class' => $form->error_wrapper_class ? $form->error_wrapper_class : 0,
'data-input_error_class' => $form->input_error_class ? $form->input_error_class : 0,
'class' => $form->form_class, 'name' => $form->name, 'id' => 'form-' . $escaped_name], $custom_form_attributes)) !!}
<input type="hidden" name="form_id" value="{{ $form->id }}">


{!! $content !!}
{!! Form::close() !!}
@endif
{{-- dd($patt_func_params) --}}