<?php

namespace Module\Blog\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Middleware\RedirectIfAuthenticated;
use Atlantis\Helpers\AtlantisRedirect;
use Atlantis\Models\Repositories\PageRepository;
use Module\Blog\Models\Repositories\BlogRepository;
use Illuminate\Support\Facades\DB;
use Module\Blog\Models\Repositories\BlogConfigRepository;

class BlogController extends Controller
{

    public static $title;
    public static $description;

    use \Module\Blog\Traits\BlogTrait;

    /**
     * <div data-pattern-func="module:blog@single"></div>
     */
    public function single()
    {

        $base_route = \Route::input('page');

        //this is dumb and needs to be replaced .. maybe change the config to have the anchor url be not connected to an actual page
        if(!intval(BlogConfigRepository::getConfigKey('single_url'))){
            return view('blog::config-alert', ['error' => 'single_url']);
        }

        $page = str_replace("/:any", "",PageRepository::getPage(BlogConfigRepository::getConfigKey('single_url'))->url);

        $entry = DB::table('blog')->where(DB::raw('CONCAT("' . $page . '/", url)'), $base_route)->first();
        
        if ($entry->status == 'draft' && is_null(auth()->user())) {
            
            return app('AtlantisRedirect')->set(redirect()->to('404'));
            
        }
        if (count($entry))
        {

            $data = array();

            $data['data'] = $entry;

            $data['comment_engine'] = BlogConfigRepository::getConfigKey('comment_engine');
            if ($entry->seo_title == ''){
                self::$title = $entry->title;
            }
            else{
                self::$title = $entry->seo_title;   
            }
            self::$description = $entry->meta_description;

            $images = \MediaTools::getImagesByGallery($entry->gallery_id);
            $data['images'] = $images;

            $ogData = [
                'type' => 'article',
                'title' => $entry->title,
                'description' => $entry->description,
                'url' => url(BlogConfigRepository::getConfigKey('single_url') . '/' . $entry->url),
                'author' => $entry->nickname
            ];

            if (isset($images[0]))
            {
                $ogData['image'] = url($images[0]->original_filename);
            }

            \Atlantis\Helpers\Assets::registerContentWithKey('opengraph', $ogData);

            return view('blog::blog-single', $data);

        } else
        {

            return app('AtlantisRedirect')->set(redirect()->to('404'));
        }
    }

    /**
     * <div data-pattern-func="module:blog@all"></div>
     */
    public function all()
    {
        $oBlogs = BlogRepository::getAllPublished();

        $featuredImages = \MediaTools::getFeaturedImages($oBlogs);

        $aParams = array();
        $aParams['oBlogs'] = $oBlogs;
        $aParams['featuredImages'] = $featuredImages;
        if(!intval(BlogConfigRepository::getConfigKey('single_url')) ){
            return view('blog::config-alert', ['error' => 'single_url']);
        }

        $single_url = PageRepository::getPage(BlogConfigRepository::getConfigKey('single_url'));

        if ($single_url->url == "/")
        {
            $aParams['single_url'] = '/';
        } else
        {
            $aParams['single_url'] = '/' . $single_url->url;
        }

        $aParams['single_url'] = str_replace(":any", "",$aParams['single_url']);

        $aParams['datetime_format'] = BlogConfigRepository::getConfigKey('datetime_format');

        //$aParams['paginator'] = '';

        return view('blog::blog-list', $aParams);
    }


    /**
    *   Show prev next blog post links 
     * <div data-pattern-func="module:blog@quicklinks"></div>
     */
    public function quicklinks()
    {
        
        $base_route = \Route::input('page');

        if(!intval(BlogConfigRepository::getConfigKey('single_url'))){
            return view('blog::config-alert', ['error' => 'single_url']);
        }

        $page = str_replace("/:any", "",PageRepository::getPage(BlogConfigRepository::getConfigKey('single_url'))->url);

        $entry = DB::table('blog')->where(DB::raw('CONCAT("' . $page . '/", url)'), $base_route)->first();
        
        $model = $entry;

        $data = [];

        $data['single_url'] = $page;

        if(count($model) && $model->posted_date)
        {
            $data['next'] = \DB::table('blog')->select('*')->where('posted_date', '>', $model->posted_date)->where('status', 'published')->orderBy('posted_date')->limit(1)->first();
            $data['prev'] = \DB::table('blog')->select('*')->where('posted_date', '<', $model->posted_date)->where('status', 'published')->orderBy('posted_date', 'DESC')->limit(1)->first();
            
            return view('blog::quick-links', $data);
        }

    }

    public function getRecentShort($params)
    {
        $amount = isset($params[0]) ? $params[0] : 3;
        return BlogRepository::getRecentShort($amount);
        
    }

    /*<div data-pattern-func="module:blog@archivePosts"></div>*/
    public function archivePosts()
    {
        $request = request();
        $fullUrl = $request->fullUrl();
        $fullUrlItems = explode("/", $fullUrl);
        if (count($fullUrlItems) >= 3) {
            $month = $fullUrlItems[count($fullUrlItems) - 1];
            if (!is_numeric($month) || (int) $month < 1 || (int) $month > 12) {
                $month = null;
            }
            $year = $fullUrlItems[count($fullUrlItems) - 2];
            if (!is_numeric($year) || (int) $year < 1 || (int) $year > 5000) {
                $year = null;
            }
        }

        $oBlogs = BlogRepository::getAllArchive($month, $year );

        $aParams = array();

        $aParams['oBlogs'] = $oBlogs;

        if(!intval(BlogConfigRepository::getConfigKey('single_url'))){
            return view('blog::config-alert', ['error' => 'single_url']);
        }

        $single_url = PageRepository::getPage(BlogConfigRepository::getConfigKey('single_url'));

        if ($single_url->url == "/")
        {
            $aParams['single_url'] = '/';
        } else
        {
            $aParams['single_url'] = '/' . $single_url->url;
        }
        $aParams['month'] = $month;
        $aParams['year'] = $year;

        $aParams['single_url'] = str_replace(":any", "",$aParams['single_url']);

        $aParams['datetime_format'] = BlogConfigRepository::getConfigKey('datetime_format');

        return view('blog::archives-list', $aParams);

    }

    /**
    * <div data-pattern-func="module:blog@archiveDatesList"></div>
    * show list of available dates
    */
    public function archiveDatesList()
    {
        $archiveAvailableDates = BlogRepository::getMakeArchivesList();
        
        $dates = array();
        $months = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        foreach ($archiveAvailableDates as $archiveAvailableDate) {
            if (!$archiveAvailableDate->month) {
                continue;
            }
            $dates[$archiveAvailableDate->year][$archiveAvailableDate->month] = $months[$archiveAvailableDate->month - 1];
        }

        if(!intval(BlogConfigRepository::getConfigKey('archives_url'))){
            return view('blog::config-alert', ['error' => 'archives_url']);
        }
        $archive_url = PageRepository::getPage(BlogConfigRepository::getConfigKey('archives_url'));


        if ($archive_url->url == "/")
        {
            $data['archive_url'] = '/';
        } else
        {
            $data['archive_url'] = '/' . $archive_url->url;
        }

        $data['archive_url'] = str_replace(":any", "",$data['archive_url']);

        $data['list'] = $dates;

        return view('blog::archives-dates-list', $data);
        
    }

    /*<div data-pattern-func="module:blog@showPostsByCategory"></div>*/
    public function showPostsByCategory()
    {
        $request = request();
        $fullUrl = $request->fullUrl();
        $fullUrlItems = explode("/", $fullUrl);
        if (count($fullUrlItems) >= 2) {
            $category = $fullUrlItems[count($fullUrlItems) - 1];
            if (is_numeric($category)) {

                $oBlogs = BlogRepository::getBlogsByCategoryId($category);

            }
            else{

                $oBlogs = BlogRepository::getByCategoryName($category);
            }
        }



        $aParams = array();

        $aParams['oBlogs'] = $oBlogs;

        if(!intval(BlogConfigRepository::getConfigKey('single_url'))){
            return view('blog::config-alert', ['error' => 'single_url']);
        }

        $single_url = PageRepository::getPage(BlogConfigRepository::getConfigKey('single_url'));

        if ($single_url->url == "/")
        {
            $aParams['single_url'] = '/';
        } else
        {
            $aParams['single_url'] = '/' . $single_url->url;
        }
        $aParams['category'] = $category;

        $aParams['single_url'] = str_replace(":any", "",$aParams['single_url']);

        $aParams['datetime_format'] = BlogConfigRepository::getConfigKey('datetime_format');

        return view('blog::blog-category', $aParams);

    }

    /**
    * <div data-pattern-func="module:blog@categoriesList"></div>
    * show list of available Categories
    */
    public function categoriesList()
    {
        if(!intval(BlogConfigRepository::getConfigKey('categories_url'))){
            return view('blog::config-alert', ['error' => 'categories_url']);
        }
        $cat_url = PageRepository::getPage(BlogConfigRepository::getConfigKey('categories_url'));
        if ($cat_url->url == "/")
        {
            $data['categories_url'] = '/';
        } else
        {
            $data['categories_url'] = '/' . $cat_url->url;
        }

        $data['categories_url'] = str_replace(":any", "",$data['categories_url']);
        
        $data['categories'] = BlogRepository::getCategory();

        return view('blog::categolies-list', $data);
        
    }
    
}
